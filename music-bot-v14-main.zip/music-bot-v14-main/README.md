## Discord V14 Music Bot

## 📑 Bot Performance

- [x] Music System
- [x] MessageButton
- [x] Slash Commands

## 🔗 Platform
![image](https://user-images.githubusercontent.com/93944142/196050222-640d6c0e-da1d-46c7-95d8-544f66a997cf.png)
![image](https://user-images.githubusercontent.com/93944142/196050226-e877002a-cbdb-419d-b1d3-449b370813bc.png)
![image](https://user-images.githubusercontent.com/93944142/196050243-7efb55f3-99c7-4cce-aabb-1a3e844357d7.png)

## 📷 Image
![image](https://user-images.githubusercontent.com/93944142/197290115-b4497988-e53d-4227-89f9-5f0fa5078ddf.png)
## 🚨 Support Server
✈ [Alex](https://discord.gg/nN8DRYqZZD)

